
import { ModelData, NGramCounts, PredictionResult } from '../types';

export class NGramPredictor {
  private data: ModelData;
  private readonly d: number = 0.75; // Hệ số chiết khấu tuyệt đối cố định theo yêu cầu

  constructor(corpus: string) {
    this.data = this.train(corpus);
  }

  private train(text: string): ModelData {
    // Tách từ: chuyển về chữ thường và loại bỏ các ký tự đặc biệt chỉ giữ lại chữ cái/số
    const tokens = text.toLowerCase().split(/\s+/).filter(t => t.length > 0);
    const unigrams: NGramCounts = {};
    const bigrams: NGramCounts = {};
    const trigrams: NGramCounts = {};

    tokens.forEach((token, i) => {
      unigrams[token] = (unigrams[token] || 0) + 1;
      
      if (i > 0) {
        const bigram = `${tokens[i - 1]} ${token}`;
        bigrams[bigram] = (bigrams[bigram] || 0) + 1;
      }
      
      if (i > 1) {
        const trigram = `${tokens[i - 2]} ${tokens[i - 1]} ${token}`;
        trigrams[trigram] = (trigrams[trigram] || 0) + 1;
      }
    });

    return {
      unigrams,
      bigrams,
      trigrams,
      totalTokens: tokens.length
    };
  }

  /**
   * Tính toán xác suất sử dụng Absolute Discounting và Back-off.
   * Công thức: P_abs(w|context) = max(count - d, 0) / count_context + lambda * P_backoff
   */
  private getProbability(target: string, context: string[]): number {
    const word = target.toLowerCase();
    
    // TRIGRAM LEVEL
    if (context.length === 2) {
      const trigramKey = `${context[0]} ${context[1]} ${word}`;
      const contextKey = `${context[0]} ${context[1]}`;
      const count = this.data.trigrams[trigramKey] || 0;
      const contextCount = this.data.bigrams[contextKey] || 0;

      if (contextCount > 0) {
        // Lambda cho Trigram (tỷ lệ trọng số dành cho back-off)
        const uniqueFollowers = Object.keys(this.data.trigrams).filter(k => k.startsWith(contextKey + ' ')).length;
        const lambda = (this.d * uniqueFollowers) / contextCount;
        
        const discountedProb = Math.max(count - this.d, 0) / contextCount;
        return discountedProb + lambda * this.getProbability(word, [context[1]]);
      }
      return this.getProbability(word, [context[1]]);
    }

    // BIGRAM LEVEL
    if (context.length === 1) {
      const bigramKey = `${context[0]} ${word}`;
      const contextKey = context[0];
      const count = this.data.bigrams[bigramKey] || 0;
      const contextCount = this.data.unigrams[contextKey] || 0;

      if (contextCount > 0) {
        const uniqueFollowers = Object.keys(this.data.bigrams).filter(k => k.startsWith(contextKey + ' ')).length;
        const lambda = (this.d * uniqueFollowers) / contextCount;
        
        const discountedProb = Math.max(count - this.d, 0) / contextCount;
        return discountedProb + lambda * this.getProbability(word, []);
      }
      return this.getProbability(word, []);
    }

    // UNIGRAM LEVEL
    const count = this.data.unigrams[word] || 0;
    return count / this.data.totalTokens;
  }

  public predict(currentInput: string): PredictionResult[] {
    const tokens = currentInput.toLowerCase().trim().split(/\s+/).filter(t => t.length > 0);
    if (tokens.length === 0) return [];

    // Lấy tối đa 2 từ cuối làm ngữ cảnh cho Trigram
    const context = tokens.slice(-2);
    
    // Lấy danh sách các từ tiềm năng (từ vựng trong corpus)
    const vocabulary = Object.keys(this.data.unigrams);
    
    return vocabulary.map(word => {
      const prob = this.getProbability(word, context);
      // Expected Loss theo Bayes: Giả sử Loss = 1 nếu chọn sai. 
      // Rủi ro tỷ lệ nghịch với xác suất.
      const expectedLoss = 1 - prob;
      
      return {
        nextWord: word,
        probability: prob,
        expectedLoss: expectedLoss,
        shouldCorrect: prob > 0.65 // Ngưỡng tin cậy cao để tự động sửa
      };
    })
    .filter(r => r.probability > 0.001) // Loại bỏ các từ xác suất quá thấp
    .sort((a, b) => b.probability - a.probability)
    .slice(0, 6);
  }
}

export const DEFAULT_CORPUS = `
hôm nay trời đẹp hôm nay trời xanh hôm nay tôi vui
tôi đang học lập trình tôi đang học trí tuệ nhân tạo
trí tuệ nhân tạo là tương lai trí tuệ nhân tạo rất thú vị
bạn có khỏe không bạn có muốn đi chơi không
xin chào các bạn xin chào mọi người
ngôn ngữ tự nhiên là một lĩnh vực khó ngôn ngữ tự nhiên rất quan trọng
mô hình n-gram là mô hình dự đoán từ mô hình n-gram dùng xác suất
absolute discounting giúp làm mượt dữ liệu absolute discounting dùng hệ số chiết khấu
back off giúp xử lý từ hiếm back off là cơ chế dự phòng
bayesian expected loss giúp tối ưu hóa quyết định bayesian expected loss giảm thiểu rủi ro
tôi thích ăn cơm tôi thích uống nước tôi thích học tập
chúng ta là sinh viên chúng ta là những người trẻ
học tập chăm chỉ thành công sẽ đến học tập là con đường ngắn nhất
dự đoán từ tiếp theo dự đoán theo ngữ cảnh
mô hình dự đoán liên tục mô hình dự đoán chính xác
`;
