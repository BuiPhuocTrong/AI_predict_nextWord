
export interface NGramCounts {
  [gram: string]: number;
}

export interface PredictionResult {
  nextWord: string;
  probability: number;
  expectedLoss: number;
  shouldCorrect: boolean;
}

export interface ModelData {
  unigrams: NGramCounts;
  bigrams: NGramCounts;
  trigrams: NGramCounts;
  totalTokens: number;
}
