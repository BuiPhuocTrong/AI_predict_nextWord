
import React, { useState, useMemo } from 'react';
import { NGramPredictor, DEFAULT_CORPUS } from './services/ngramModel';
import { PredictionResult } from './types';

const App: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [predictions, setPredictions] = useState<PredictionResult[]>([]);
  const [lastCorrection, setLastCorrection] = useState<{ original: string, fixed: string } | null>(null);
  
  const predictor = useMemo(() => new NGramPredictor(DEFAULT_CORPUS), []);

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    setInputText(value);

    // Xử lý dự đoán liên tục
    if (value.length > 0) {
      const results = predictor.predict(value);
      setPredictions(results);

      // Logic đánh giá lỗi từ cuối cùng dựa trên ngữ cảnh trước đó
      const words = value.trim().split(/\s+/);
      if (words.length >= 2) {
        const currentWord = words[words.length - 1].toLowerCase();
        const prevContext = words.slice(0, -1).join(' ');
        const candidates = predictor.predict(prevContext);
        
        // Nếu từ người dùng nhập có xác suất thấp hơn nhiều so với từ AI dự đoán mạnh nhất
        const best = candidates[0];
        if (best && best.nextWord !== currentWord && best.probability > 0.7) {
          setLastCorrection({ original: currentWord, fixed: best.nextWord });
        } else {
          setLastCorrection(null);
        }
      }
    } else {
      setPredictions([]);
      setLastCorrection(null);
    }
  };

  const applyCorrection = () => {
    if (!lastCorrection) return;
    const words = inputText.trim().split(/\s+/);
    words[words.length - 1] = lastCorrection.fixed;
    setInputText(words.join(' ') + ' ');
    setLastCorrection(null);
  };

  // Lấy 2 từ cuối cùng đang được dùng làm context
  const currentContext = useMemo(() => {
    const words = inputText.trim().split(/\s+/);
    return words.slice(-2).join(' ');
  }, [inputText]);

  return (
    <div className="min-h-screen bg-neutral-100 flex flex-col items-center py-10 px-4 font-sans">
      <div className="max-w-4xl w-full bg-white rounded-3xl shadow-2xl overflow-hidden border border-neutral-200">
        
        {/* Header Section */}
        <div className="bg-gradient-to-r from-blue-700 to-indigo-800 p-8 text-white">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-3xl font-extrabold tracking-tight">AI N-Gram Chatbot</h1>
              <p className="text-blue-100 mt-1 font-light italic">Hệ thống dự đoán ngôn ngữ & Chỉnh sửa lỗi thông minh</p>
            </div>
            <div className="bg-white/20 px-3 py-1 rounded-full text-xs font-mono">
              v2.1 Trigram
            </div>
          </div>
        </div>

        <div className="flex flex-col md:flex-row h-[600px]">
          {/* Left: Input Area */}
          <div className="flex-1 p-6 border-r border-neutral-100 flex flex-col">
            <div className="mb-4">
              <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest">Ngữ cảnh hiện tại (Trigram context)</span>
              <div className="flex gap-2 mt-1">
                {currentContext ? (
                  currentContext.split(' ').map((w, i) => (
                    <span key={i} className="px-2 py-1 bg-blue-50 text-blue-700 rounded border border-blue-100 text-sm font-medium">
                      {w}
                    </span>
                  ))
                ) : <span className="text-sm text-neutral-400">Đang chờ nhập từ...</span>}
              </div>
            </div>

            <textarea
              className="flex-1 w-full p-5 text-xl text-neutral-800 bg-neutral-50 rounded-2xl border-2 border-transparent focus:border-blue-500 focus:bg-white transition-all outline-none resize-none shadow-inner"
              placeholder="Bắt đầu nhập nội dung..."
              value={inputText}
              onChange={handleInputChange}
            />

            {lastCorrection && (
              <div className="mt-4 p-4 bg-rose-50 border border-rose-100 rounded-xl flex items-center justify-between animate-in fade-in slide-in-from-bottom-2">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-rose-500 text-white rounded-full flex items-center justify-center text-xs">
                    <i className="fas fa-spell-check"></i>
                  </div>
                  <div>
                    <p className="text-xs text-rose-600 font-bold uppercase">Phát hiện rủi ro sai sót</p>
                    <p className="text-sm text-neutral-700">Thay thế <span className="line-through text-neutral-400">"{lastCorrection.original}"</span> bằng <span className="font-bold text-rose-700">"{lastCorrection.fixed}"</span>?</p>
                  </div>
                </div>
                <button 
                  onClick={applyCorrection}
                  className="bg-rose-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-rose-700 transition-colors shadow-sm"
                >
                  Sửa ngay
                </button>
              </div>
            )}
          </div>

          {/* Right: Prediction Panel */}
          <div className="w-full md:w-80 bg-neutral-50 p-6 overflow-y-auto">
            <h3 className="text-xs font-black text-neutral-400 uppercase tracking-widest mb-6 border-b border-neutral-200 pb-2">
              Bảng dự đoán (Bayes Rank)
            </h3>

            <div className="space-y-4">
              {predictions.length > 0 ? (
                predictions.map((p, idx) => (
                  <div key={idx} className="group cursor-default">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-lg font-bold text-neutral-700 group-hover:text-blue-600 transition-colors">
                        {p.nextWord}
                      </span>
                      <span className="text-[10px] font-mono font-bold bg-neutral-200 text-neutral-600 px-1.5 rounded">
                        {(p.probability * 100).toFixed(1)}%
                      </span>
                    </div>
                    {/* Progress Bar for Probability */}
                    <div className="w-full h-1.5 bg-neutral-200 rounded-full overflow-hidden">
                      <div 
                        className={`h-full transition-all duration-500 ${idx === 0 ? 'bg-blue-600' : 'bg-neutral-400'}`}
                        style={{ width: `${p.probability * 100}%` }}
                      />
                    </div>
                    {/* Expected Loss label */}
                    <div className="flex justify-between mt-1">
                      <span className="text-[9px] text-neutral-400 uppercase font-bold">Expected Loss:</span>
                      <span className="text-[9px] font-mono text-neutral-500">{p.expectedLoss.toFixed(4)}</span>
                    </div>
                  </div>
                ))
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-center py-20">
                  <i className="fas fa-terminal text-3xl text-neutral-200 mb-4"></i>
                  <p className="text-xs text-neutral-400 font-medium">Chưa có dữ liệu dự đoán cho ngữ cảnh này.</p>
                </div>
              )}
            </div>
            
            <div className="mt-10 p-4 bg-white rounded-xl border border-neutral-200">
              <p className="text-[10px] text-neutral-500 leading-relaxed italic">
                Cơ chế **Absolute Discounting (d=0.75)** giúp phân phối lại xác suất cho các từ chưa xuất hiện trong tập huấn luyện ban đầu.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Test Cases Info */}
      <div className="max-w-4xl w-full mt-6 text-neutral-500 text-[11px] flex flex-wrap gap-4 justify-center">
        <span><i className="fas fa-check-circle text-green-500"></i> Trigram Model</span>
        <span><i className="fas fa-check-circle text-green-500"></i> Absolute Discounting (d=0.75)</span>
        <span><i className="fas fa-check-circle text-green-500"></i> Katz Back-off</span>
        <span><i className="fas fa-check-circle text-green-500"></i> Bayesian Expected Loss</span>
      </div>
    </div>
  );
};

export default App;
